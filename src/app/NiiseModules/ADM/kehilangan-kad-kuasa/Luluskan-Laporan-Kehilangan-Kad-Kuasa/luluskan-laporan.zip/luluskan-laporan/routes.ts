import { Routes } from "@angular/router";

export const routes: Routes = [
  {
    path: 'luluskan-laporan-kehilangan',
    loadComponent: () =>
      import('./luluskan-laporan/luluskan-laporan-kehilangan.component').then(
        (m) => m.LuluskanLaporanKehilanganComponent
      )
  },
];
